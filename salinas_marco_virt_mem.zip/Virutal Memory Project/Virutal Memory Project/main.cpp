#include<iostream>
#include<string>
#include<fstream>

using namespace std;

int getPage(int num)
{
	int buf = 65280; // 1111 1111 0000 0000
	return (num & buf) >> 8;
}

int getOffset(int num)
{
	int buf = 255; // 1111 1111
	return (num & buf);
}

void pageAndOffset(int num)
{
	int frame = 0;
	int physAddress = 256 + getOffset(num);
	
	cout << "Logical: ";
	//added if statements for text formatting purposes
	if (num < 10000)
	{
		cout << " ";
	}
	cout << num << " (page: ";
	if (getPage(num) < 100)
	{
		cout << " ";
	}
	if (getPage(num) < 10)
	{
		cout << " ";
	}
	cout << getPage(num) << ", offset: ";
	if (getOffset(num) < 100)
	{
		cout << " ";
	}
	if (getOffset(num) < 10)
	{
		cout << " ";
	}
	cout << getOffset(num) << ")";
	
	//cout << "Logical: " << num << " page(: " << getPage(num) << ", offset: " << getOffset(num) << ")";
}

void readAddresses(string filename)
{
	ifstream aFile(filename);
	if (aFile.is_open())
	{
		int address;
		int frame = 0;
		
	
		while (aFile >> address)
		{
			int physAddress = frame++ * 256 + getOffset(address); //formula to get physical address
			pageAndOffset(address);
			cout << " ---> physical:   " << physAddress << endl;
			if (frame % 5 == 0)
				cout << endl;
		}
		aFile.close();
	}
}

int main()
{
	int pageTable[256];
	int TLB[15];
	int phyMemory[256];

	readAddresses("addresses.txt");
	
	system("pause");
	return 0;
}